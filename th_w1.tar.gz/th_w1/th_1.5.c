// th_1.5.c
// determine the clock ticks per second in the system
 
#include <stdio.h>
#include <limits.h>
#include <unistd.h>

void main (void)
{
    printf(" use sysconf(_SC_CLK_TCK) to find the value: %ld\n", 
        sysconf(_SC_CLK_TCK));
}


