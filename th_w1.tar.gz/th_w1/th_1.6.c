// th_1.6.c
// determine the clock ticks per second in the system
 
#include <stdio.h>

// this function recursively traverses from the string end back to the beginning
// each traversal increments by 6 positions.
// when it lands at the current position the puchar takes the char value there
// then subtract 1 from the ascii value to render the final value to be shown.
// for example, the last increment is at the character 'H' position,
// then putchar gets the value of *str -1 that is 'G'
// As the recursive function reaches back to the beginning that is the double
// quote character, again putchar get *str-1 that is ''!'
// thus ''H', 'p', 'p', 'e', '!', 'K', 'p', 'c', 'double quote' turn into "Good Job!"
// haha ...

void fn(char *str) {
    if (*str) {
        fn(str+6);
        putchar(*str-1);
    }
    return;
}

void main(void) {
/* Some, World Currencies */
    char *str="\"YeN! cEnT! pEsO! KrOnEr! pEnCe! LeMpIrA! pUlS! Hi!!\"";
    fn(str);
    putchar('\n');
    return;
}


