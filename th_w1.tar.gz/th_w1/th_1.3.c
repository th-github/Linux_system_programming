// th_1.3.c
// this code may not work because of the c is char while the getchar returns int
// EOF is defined as -1. To test use Ctrl + D to simulate EOF  
#include <stdio.h>

void main(void) {
    char c;
    while ( (c=getchar()) != EOF )
        putchar(c);   
}


