// th_1.2.c
// compute the calendar time accumulated value
 
#include <stdio.h>
#include <limits.h>

void main (void)
{
    unsigned int y = 0;
    int int_max = INT_MAX;
    
    y = (int)(int_max/31557600);
    printf(" The time value stored in signed int since 1970 may overflow in year of %d\n", 
        y+1970);   
}


