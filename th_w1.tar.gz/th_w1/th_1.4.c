// th_1.4.c
// determine the max number of file open per process
 
#include <stdio.h>
#include <limits.h>
#include <unistd.h>

void main (void)
{

    printf(" The max number of file open per process is: %d\n", 
        _POSIX_OPEN_MAX);   // static limit
    printf(" use sysconf(_SC_OPEN_MAX) to find the limit: %ld\n", 
        sysconf(_SC_OPEN_MAX));
}


