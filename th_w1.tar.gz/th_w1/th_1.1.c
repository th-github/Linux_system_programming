// th_user_cpu_time.c

#include <stdio.h>

void main (void)
{
    while (1)
        ;   // the CPU is 100% dedicated to user space in waiting forever
}


