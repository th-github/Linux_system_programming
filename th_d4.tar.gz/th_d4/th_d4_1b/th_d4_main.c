// th_d4_main.c
// use for testing th_d4_1b.c   proc file rd/wr in user space

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
 
void main(void)
{
	char buf[100] = "";
	
	printf(" Opening /proc/mydev \n");
	int fd = open("/proc/mydev", O_RDWR);
	if (!fd) {
		printf(" Failed to open the file. Exit.\n");
		return;
	}
		
	printf(" read mydev:\n");
	read(fd, buf, 100);
	puts(buf);
 
	lseek(fd, 0 , SEEK_SET);
	printf(" write to mydev\n");
	write(fd, "2019", 6);
	
	lseek(fd, 5 , SEEK_SET);
	printf(" read /proc/mydev:\n");
	read(fd, buf, 20);
	
	puts(buf);
}	
