#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kernel.h>   
#include <linux/proc_fs.h>
#include <linux/fs.h>		// for basic filesystem
#include <linux/uaccess.h>
#define BUFSIZE  100
 
 
MODULE_LICENSE("Dual BSD/GPL");
 
static char* group_name = "Tom Hua";
static int group_num=1;
module_param(group_num,int,0660);
 
static struct proc_dir_entry *ent;
 
static ssize_t mywrite(struct file *file, const char *ubuf, 
						size_t count, loff_t *ppos) 
{
	int num, c, i;
	char buf[BUFSIZE];
	
	printk( KERN_DEBUG "write handler\n");
	
	if(*ppos > 0 || count > BUFSIZE) {
		printk( KERN_DEBUG "write handler error: count > BUFSIZE\n");
		return -EFAULT;
	}	
	if(copy_from_user(buf, ubuf, count)) {
		printk( KERN_DEBUG "write handler error: copy_from_user\n");
		return -EFAULT;
	}
	num = sscanf(buf,"%d", &i);
	if(num != 1) {
		printk( KERN_DEBUG "write handler error: invalid number of argment\n");
		return -EFAULT;
	}

	group_num = i;
	c = strlen(buf);
	*ppos = c;
	return c;
}
 
static ssize_t myread(struct file *file, char __user *ubuf,
					size_t count, loff_t *ppos) 
{
	char buf[BUFSIZE] = "";
	int len=0;
	
	printk( KERN_DEBUG "read handler\n");
	
	if(*ppos > 0 || count < BUFSIZE)
		return 0;
	len += sprintf(buf," group name: %s\n", group_name);
	len += sprintf(buf + len," group number: %d\n", group_num);
	len += sprintf(buf + len," buffer length allocated: %d\n", BUFSIZE);
	len += sprintf(buf + len," length of buffer used: %d\n", len);
	
	if(copy_to_user(ubuf,buf,len))
		return -EFAULT;
	*ppos = len;
	return len;
}
 
static const struct file_operations myops = 
{
	.owner = THIS_MODULE,
	.read = myread,
	.write = mywrite,
};
 
static int _init(void)
{
	ent=proc_create("mydev",0660,NULL,&myops);
	printk(KERN_ALERT "_init ...\n");
	return 0;
}
 
static void _cleanup(void)
{
	proc_remove(ent);
	printk(KERN_WARNING "_init ...\n");
}
 
module_init(_init);
module_exit(_cleanup);
