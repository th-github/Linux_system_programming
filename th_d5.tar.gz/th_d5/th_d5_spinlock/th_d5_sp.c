// th_d5_sp.c 
// simple *spinlock* example test with main.c
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kernel.h>   
#include <linux/proc_fs.h>
#include <linux/fs.h>		// for basic filesystem
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <generated/utsrelease.h>
#include <linux/sched.h>
#include <linux/spinlock.h>
	
#define BUFSIZE  100
 
 
MODULE_LICENSE("Dual BSD/GPL");
 
static char* group_name = "Tom Hua";
static int group_num=1;
module_param(group_num,int,0660);

spinlock_t proc_hello_sp;
rwlock_t proc_hello_rw;
	 
static struct proc_dir_entry *ent;
 
static ssize_t mywrite(struct file *file, const char *ubuf, 
						size_t count, loff_t *ppos) 
{
	int num = 0, c, i = 0;
	char buf[BUFSIZE];
	
	printk( KERN_DEBUG "write handler\n");
	
	if(*ppos > 0 || count > BUFSIZE) {
		printk( KERN_DEBUG "write handler error: count > BUFSIZE\n");
		return -EFAULT;
	}	
	
	// spinlock get - returns nonzero on success. zero otherwise.
	if (write_trylock(&proc_hello_rw)) 
	{
        printk(KERN_ALERT " At %ld: got write lock!\n", jiffies);

		if(copy_from_user(buf, ubuf, count)) {
			printk( KERN_DEBUG "write handler error: copy_from_user\n");
			return -EFAULT;
		}
		num = sscanf(buf,"%d", &i);
		
    // spinlock release
    write_unlock(&proc_hello_rw);
    printk(KERN_ALERT " At %ld: release write lock!\n", jiffies);
   
	}
	if(num != 1) {
		printk( KERN_DEBUG "write handler error: \
		        invalid number of argment\n");
		return -EFAULT;
	}

	group_num = i;
	c = strlen(buf);
	*ppos = c;
	return c;
}
 
static ssize_t myread(struct file *file, char __user *ubuf,
					size_t count, loff_t *ppos) 
{
	char buf[BUFSIZE] = "";
	int len=0;
	
	printk( KERN_DEBUG "read handler\n");
	
	if(*ppos > 0 || count < BUFSIZE)
		return 0;
		
	read_trylock(&proc_hello_rw);
    printk(KERN_ALERT " At %ld: got read lock!\n", jiffies);

	len += sprintf(buf," group name: %s\n", group_name);
	len += sprintf(buf + len," group number: %d\n", group_num);
	len += sprintf(buf + len," buffer length allocated: %d\n", BUFSIZE);
	len += sprintf(buf + len," length of buffer used: %d\n", len);
	
	if(copy_to_user(ubuf,buf,len)) {
	    read_unlock(&proc_hello_rw);
		return -EFAULT;
	}
	read_unlock(&proc_hello_rw);
    printk(KERN_ALERT " At %ld: released read lock!\n", jiffies);

	
	*ppos = len;
	return len;
}
 
static const struct file_operations myops = 
{
	.owner = THIS_MODULE,
	.read = myread,
	.write = mywrite,
};
 
static int _init(void)
{
	ent=proc_create("mydev",0660,NULL,&myops);
	printk(KERN_ALERT "_init ...\n");
	  
	spin_lock_init(&proc_hello_sp);
	rwlock_init(&proc_hello_rw);
		    
	return 0;
}
 
static void _cleanup(void)
{
	proc_remove(ent);
	printk(KERN_WARNING "_init ...\n");
}
 
module_init(_init);
module_exit(_cleanup);
