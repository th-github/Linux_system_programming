// th_d5_semaphore.c 
// simple *semaphore* example with rwsem (main.c)
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kernel.h>   
#include <linux/proc_fs.h>
#include <linux/fs.h>		// for basic filesystem
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <generated/utsrelease.h>
#include <linux/sched.h>
#include <linux/rwsem.h>
	
#define BUFSIZE  100
 
 
MODULE_LICENSE("Dual BSD/GPL");
 
static char* group_name = "Tom Hua";
static int group_num=1;
module_param(group_num,int,0660);

struct rw_semaphore *proc_hello_sem;
	 
static struct proc_dir_entry *ent;
 
static ssize_t mywrite(struct file *file, const char *ubuf, 
						size_t count, loff_t *ppos) 
{
	int num = 0, c, i = 0;
	char buf[BUFSIZE];
	
	printk( KERN_DEBUG "write handler\n");
	
	if(*ppos > 0 || count > BUFSIZE) {
		printk( KERN_DEBUG "write handler error: count > BUFSIZE\n");
		return -EFAULT;
	}	
	
	if (down_write_trylock(proc_hello_sem)) 
	{
		if(copy_from_user(buf, ubuf, count)) {
			printk( KERN_DEBUG "write handler error: copy_from_user\n");
			up_write(proc_hello_sem);
			return -EFAULT;
		}
		num = sscanf(buf,"%d", &i);
		
		// semaphore incr
    	up_write(proc_hello_sem);
    	printk(KERN_ALERT "2470:5.1a: released write rwsem!\n");
    
	}
	if(num != 1) {
		printk( KERN_DEBUG "write handler error: invalid number of argment\n");
		return -EFAULT;
	}

	group_num = i;
	c = strlen(buf);
	*ppos = c;
	return c;
}
 
static ssize_t myread(struct file *file, char __user *ubuf,
					size_t count, loff_t *ppos) 
{
	char buf[BUFSIZE] = "";
	int len=0;
	
	printk( KERN_DEBUG "read handler\n");
	
	if(*ppos > 0 || count < BUFSIZE)
		return 0;
		
		// down_read has a return type of void
	down_read(proc_hello_sem);
       	printk(KERN_ALERT "2470:5.1a: got read rwsem!\n");


	len += sprintf(buf," group name: %s\n", group_name);
	len += sprintf(buf + len," group number: %d\n", group_num);
	len += sprintf(buf + len," buffer length allocated: %d\n", BUFSIZE);
	len += sprintf(buf + len," length of buffer used: %d\n", len);
	
	if(copy_to_user(ubuf,buf,len)) {
		up_read(proc_hello_sem);
		return -EFAULT;
	}
	up_read(proc_hello_sem);
	
	*ppos = len;
	return len;
}
 
static const struct file_operations myops = 
{
	.owner = THIS_MODULE,
	.read = myread,
	.write = mywrite,
};
 
static int _init(void)
{
	ent=proc_create("mydev",0660,NULL,&myops);
	printk(KERN_ALERT "_init ...\n");
	
	proc_hello_sem=(struct rw_semaphore *)
    kmalloc(sizeof(struct rw_semaphore),GFP_KERNEL);
    init_rwsem(proc_hello_sem);
     
	return 0;
}
 
static void _cleanup(void)
{
	kfree(proc_hello_sem);
	proc_remove(ent);
	printk(KERN_WARNING "_init ...\n");
}
 
module_init(_init);
module_exit(_cleanup);
