/* mysh.c */

#define BUFSZ 512
#define ERRBUFSZ 512

#define MYSH_PROMPT "mysh> "

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <setjmp.h>
#include <string.h>
#include <ctype.h>

#define TIMEOUT_TIMEDIO 15
#define BUFSZ 512
#define ERRBUFSZ 512
static sigjmp_buf jmpbuf;
static void sigalrm_handler(int signo);
int pipefd[2];	// for pipe()
	
int isEmptyline(char* s);	// check for empty line input
int do_cmd(char *buf, int len, int linenum, char *errbuf);
int parse_cmd(char *buf, char **vbuf, char *errbuf);
int builtin_cmd(char **argv, int linenum);
int process_cmd(char **argv, int linenum);

int builtin_cmd(char **argv, int linenum) {

	int st;

	if ((strcmp(*argv,"exit") == 0) ||
		  (strcmp(*argv,"ex") == 0) || 
		  (strcmp(*argv,"quit") == 0) || 
		  (strcmp(*argv,"q") == 0) ) {
		return -2;
	}
	else if (strcmp(*argv,"cd") ==0) {
		if ((argv[1]) && (st=chdir(argv[1])) != 0) {
			fprintf(stderr,"ERR: \"cd\" to '%s' failed! (Line=%d)\n",
				argv[1],linenum);
			return -1;
		}
		return 1;
	}
	else if (strcmp(*argv,"hello") ==0) {
		fprintf(stderr,"\nHello! from process '%d'. (Line=%d)\n",
				getpid(),linenum);
		return 1;
	}
	else if (strcmp(*argv,"myls") ==0) {
		fprintf(stderr," this is myls program\n");	
		//printf(" argv: %s\n", *argv);
		process_cmd(argv, 0);	
		return 1;
	}
	else if (strcmp(*argv,"mycat") ==0) {
		fprintf(stderr," this is mycat program\n");	
		process_cmd(argv, 0);	
		return 1;
	}
		
	return 0;
}
	
int process_cmd(char **argv, int linenum) {

	pid_t	cpid=fork();
	
	if (cpid<0) {
		fprintf(stderr,"ERR: \"fork\" error! (Line=%d)\n",
				linenum);
		exit (-1);
	}
	else if (cpid==0) {
		// child executes in the foreground
		if (execvp(argv[0],argv) < 0) {
			fprintf(stderr," can't find (%s), missing the full path?\n",
					argv[0]);
			_exit (errno);
		}
	}
	else {
		// parent .. waiting in the background.
		int st;	
		cpid=wait(&st); // block here
		printf(" process_cmd completed.\n");
	}
	return 1;
}
		
int parse_cmd(char *buf, char **vbuf, char *errbuf) {

	int i=0, st = 1;
	char *delim=" ,\t,\n";
	char *tok = NULL;
	char input[256] = {0};
	
	strncpy(input, buf, strlen(buf));
	st = isEmptyline(input);
	
	if (st == 1)
		return 0;
	tok=strtok(buf, " \t\n");
	
	while (tok) {
		vbuf[i]=(char *)malloc(BUFSZ*sizeof(char));	
		strcpy(vbuf[i],tok);
		tok=strtok(NULL,delim);
		i++;
	}
	
	if (i>0)
		vbuf[i]=0;  // terminate the line
    //printf(" cmd: %s\n", *vbuf);
	return i;
		
}

int isEmptyline(char* s)
{
	while(*s) {
		if (!isspace(*s))
			return 0;
		s++;
	}	
	return 1;
}


int do_cmd(char *buf, int len, int linenum, char *errbuf) {

	int i=0, st = 0;
	char *vbuf[128];	
	char input[128] = {0};
	int maxargs=sizeof(vbuf)/sizeof(char *);
	int numargs = 0;

	read(pipefd[0],input,len);
		
	if ((numargs=parse_cmd(input,vbuf,errbuf))==maxargs) {
		fprintf(stderr,"ERR: too many args (Line=%d)\n",linenum);
		return -2;
	}
	else {
		//execute the command/input
		if (numargs > 0) {			
			st = builtin_cmd(vbuf,linenum);
			if (st == 0) {			
				printf(" input: %s, arguments: %d\n", *vbuf, numargs);
				process_cmd(vbuf,linenum);
			}	
		}				
	}

	for (i=0;i<numargs; i++) {
		if (vbuf[i]) {				
			free(vbuf[i]);
		}
	}
	if (st == -2) {
		return 0;
	}	

	return 1;
}

int main(int argc, char **argv) {

	int st = -1;
	pid_t chlpid = -1;
	int i;
	int linenum=0;
    
	// create a pipe:
	if (pipe(pipefd) == -1)
	{
		printf(" pipe() failed. exit\n");
		exit(EXIT_FAILURE);
	}
	
	char *buf=(char *)malloc(BUFSZ*sizeof(char)); 
	char *errbuf=(char *)malloc(ERRBUFSZ*sizeof(char)); 
		
	char *mysh = "";

	FILE *rfp=stdin;

	if (isatty(fileno(rfp))) {
	  	mysh = MYSH_PROMPT;
		fprintf(stderr,"%s",mysh);
	}

	while (fgets(buf,BUFSZ,rfp)) 
	{
		linenum++;
		buf[strlen(buf)-1]=0;
		write(pipefd[1], buf, strlen(buf));		
		st = do_cmd(buf, strlen(buf), linenum,errbuf);
		if (st == 0)
			break;
	}
	
	free(errbuf);
	free(buf);
}

